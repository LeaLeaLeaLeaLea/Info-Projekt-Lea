import ch.aplu.jgamegrid.*;
import java.awt.Color;
import java.awt.event.KeyEvent;

class Gold extends Actor
{

  public Gold()
  {
    super("goldcoin.png");
  }
} 