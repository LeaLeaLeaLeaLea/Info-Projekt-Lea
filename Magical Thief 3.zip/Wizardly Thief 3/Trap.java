import ch.aplu.jgamegrid.*;
import java.awt.Color;
import java.awt.event.KeyEvent;

class Trap extends Actor
{

  public Trap()
  {
    super("poisontrap.png");
  }
} 